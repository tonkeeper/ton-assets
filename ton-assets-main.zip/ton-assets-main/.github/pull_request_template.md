Please make sure you change the original ones `.yaml` fiels in directories `accounts/`, `collections/` or  `jettons/` and do not touch automatically generated .json files in the repository root.


Пожалуйста, убедитесь, что вы изменяете исходные `.yaml` файлы в директориях  `accounts/`, `collections/` или  `jettons/` и не трогаете автоматически сгенерированные файлы `.json` в корне репозитория.